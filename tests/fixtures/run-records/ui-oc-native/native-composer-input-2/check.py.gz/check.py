from pathlib import Path
import json,hashlib,gzip
p=Path(__file__).parent;r=p.parents[2];e=json.loads((p/'expected.json').read_text());j=json.loads((p/'vitest.json').read_text())
assert len(e)==17 and sum(e.values())==192
prior=r/'tests/fixtures/run-records/ui-oc-native/native-session-notice-1';raw=gzip.decompress((prior/'expected.json.gz').read_bytes());assert hashlib.sha256(raw).hexdigest()==(p/'baseline-expected.sha256').read_text().strip()=='0dadf20c901c203ae9ba50dc2110d4eb1be7fdcfe0173d435855ddb566b6c631'
old=json.loads(raw);assert {k:v for k,v in e.items() if k!='native-composer-input.test.ts'}==old and e['native-composer-input.test.ts']==16
assert j['success'] is True and j['numTotalTests']==192 and j['numPassedTests']==192 and j['numFailedTests']==0 and j['numPendingTests']==0 and j.get('numTodoTests',0)==0
assert len(j['testResults'])==17
actual={}
for suite in j['testResults']:
 name=Path(suite['name']).name;assert name not in actual and suite['status']=='passed';cases=suite['assertionResults'];assert len(cases)==e[name] and all(c['status']=='passed' for c in cases);actual[name]=len(cases)
assert actual==e
assert set(Path(x).name for x in (p/'targets.txt').read_text().splitlines())==set(e)
print('PASS EXACT192/17, every suite+case passed, no skips/pending/todo/missing, old176 expected unchanged SHA + fixed16 input cases. Controlled adapter/Source regressions, NOT composer/browser/physical IME acceptance.')
