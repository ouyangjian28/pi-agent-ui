// Owned empty-HOME reproduction; never inherit credentials and never print arbitrary child output.
import { spawnPi } from '../../../apps/server/src/host/pi-child.ts';
import { writeFileSync } from 'node:fs';
import assert from 'node:assert/strict';
const events = [], stderr = [];
let child;
let timedOut = false;
const exited = new Promise(resolve => {
  child = spawnPi(['-p', '只回复一个字：好'], {
    onEvent: event => events.push(event),
    onStderr: text => stderr.push(text),
    onExit: (code, signal) => resolve({ code, signal }),
  });
});
const timer = setTimeout(() => { timedOut = true; child.kill('SIGTERM'); }, 45000);
const result = await exited;
clearTimeout(timer);
const messages = [...stderr, ...events.map(e => e.error?.message ?? e.errorMessage ?? e.message).filter(v => typeof v === 'string')].join('\n');
const safeMatches = [...new Set(messages.match(/No API key found for [A-Za-z0-9_-]+\.?/g) ?? [])];
const summary = { ...result, timedOut, eventTypes: events.map(e => e.type), stderrLineCount: stderr.length, safeMissingAuthMessages: safeMatches, emptyHome: true, nonLoopbackGuard: 'selfchecked separately; Node guard, not OS sandbox', credentialsPrinted: false, proofScope: 'Original spawnPi, empty HOME/env-i. Child failure is not converted to a test pass.' };
writeFileSync(process.env.DIAGNOSTIC_OUTPUT, JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify(summary));
assert.equal(timedOut, false, 'Owned diagnostic child timed out');
