from pathlib import Path
import json,hashlib,gzip
r=Path.cwd();p=r/'.pi/oc-bridge-checks/native-source-composer-3';b=r/'tests/fixtures/run-records/ui-oc-native/native-composer-input-2';raw=gzip.decompress((b/'expected.json.gz').read_bytes());assert hashlib.sha256(raw).hexdigest()==(p/'baseline-expected.sha256').read_text().strip();old=json.loads(raw);expected=json.loads((p/'expected.json').read_text());assert len(old)==17 and sum(old.values())==192 and {k:v for k,v in expected.items() if k!='native-source-composer.test.tsx'}==old and expected['native-source-composer.test.tsx']==14 and len(expected)==18 and sum(expected.values())==206
j=json.loads((p/'results.json').read_text());assert j['success'] is True and j['numTotalTests']==206 and j['numPassedTests']==206 and j['numFailedTests']==0 and j['numPendingTests']==0 and j['numTodoTests']==0;results=j['testResults'];assert len(results)==18;actual={}
for suite in results:
 name=Path(suite['name']).name;assert name not in actual and suite['status']=='passed';cases=suite['assertionResults'];assert all(c['status']=='passed' for c in cases);actual[name]=len(cases)
assert actual==expected
print('PRE-fixed206/18/eachcase/no skip/pending/todo/missing/duplicate target checked. Old192 expected map SHA unchanged; SourceVM+replacementEditor ONLY, actual original UI/send/IME not proven.')
